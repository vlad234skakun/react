const ShoppingList = ({items}) =>{

    const element = items.map((item, index) => <li key={index}>{item}</li>)
    return (
        <div>
            {items.length > 0 ? (<ul>{element}</ul>) : ( <p>Список не найден</p> ) }
        </div>
    );
};

export default ShoppingList 



