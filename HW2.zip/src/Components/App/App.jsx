import { useState } from 'react'

import './App.css'
import Greeting from '../Greeting/Greeting'
import ShoppingList from '../ShoppingList/ShoppingList'
import OrderStatus from '../OrderStatus/OrderStatus'

function App() {
  const items = ["Хлеб","Молоко","Сыр"]
  const orders = [
    { orderId: 101, status: "обработан" },
    { orderId: 102, status: "в пути" },
    { orderId: 103, status: "доставлен" },
  ]

  return (
    <>
    <Greeting name="Alex"/>
    <Greeting name="Vlad"/>
    <Greeting name="Leo"/>

    <h2>Продукты</h2>
    <ShoppingList items = {items}/>

    <h2>Статус заказа</h2>
    <div>{orders.map((order, index)=>(<OrderStatus key={index} orderId={order.orderId} status={order.status}/>))}</div>
    </>
  )
}

export default App
